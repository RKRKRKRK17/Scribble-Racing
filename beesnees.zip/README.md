# Scribble Racers 3D: online leaderboard setup

Files: `index.html` (the whole game), `supabase-setup.sql` (leaderboard table).
With no setup, the game works and saves times on that device only. Follow these steps to make the leaderboard shared.

## 1. Free leaderboard backend (Supabase, free tier)
1. Create a project at supabase.com.
2. Open **SQL Editor**, paste `supabase-setup.sql`, click **Run**.
3. Open **Project Settings > API**. Copy the **Project URL** and the **anon public** key.
4. In `index.html`, find `const LB={url:'',key:''}` and paste them in:
   `const LB={url:'https://xxxx.supabase.co',key:'eyJ...'}`
   (The anon key is meant to be public. The row-level-security rules in the SQL limit what it can do.)

## 2. Free hosting + free domain
Upload `index.html` to any one of these. Each gives you a free address:
- **Cloudflare Pages**: `yourname.pages.dev` (Workers & Pages > Create > Pages > Upload assets)
- **Netlify**: `yourname.netlify.app` (drag the folder onto app.netlify.com/drop)
- **GitHub Pages**: `username.github.io/repo` (put the file in a repo, Settings > Pages)

## Known limits
- Times are measured in the browser, so a determined cheater could post a fake time. The SQL rejects impossible values (under 15s) and names are capped at 12 characters, but there is no full anti-cheat.
- Each player appears once per track on the board, using their best time. Names are not unique or protected.
