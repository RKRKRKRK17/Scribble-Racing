-- Run this once in Supabase: SQL Editor -> New query -> paste -> Run
create table public.scores (
  id bigint generated always as identity primary key,
  created_at timestamptz not null default now(),
  track smallint not null check (track between 0 and 3),
  name text not null check (char_length(name) between 1 and 12),
  racer text not null check (char_length(racer) between 1 and 20),
  secs numeric(7,2) not null check (secs between 15 and 900)
);

create index scores_track_secs on public.scores (track, secs);

alter table public.scores enable row level security;

-- Anyone can read the leaderboard and add a time. Nobody can edit or delete via the public key.
create policy "anyone can read" on public.scores for select to anon using (true);
create policy "anyone can submit" on public.scores for insert to anon with check (true);
